//
//  PayEgisAuthentication.h
//  PayEgisAuthentication
//
//  Created by jian.yang on 17/6/21.
//  Copyright © 2017年 jian.yang. All rights reserved.
//

#import <UIKit/UIKit.h>
#import <PayEgisFace/PayegisFaceSDK.h>
//! Project version number for PayEgisAuthentication.
FOUNDATION_EXPORT double PayEgisAuthenticationVersionNumber;

//! Project version string for PayEgisAuthentication.
FOUNDATION_EXPORT const unsigned char PayEgisAuthenticationVersionString[];

// In this header, you should import all the public headers of your framework using statements like #import <PayEgisAuthentication/PublicHeader.h>


