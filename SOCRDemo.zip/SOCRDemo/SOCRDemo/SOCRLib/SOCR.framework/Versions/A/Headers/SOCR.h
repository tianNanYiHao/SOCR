//
//  SOCR.h
//  pppDemo
//
//  Created by tianNanYiHao on 2018/7/11.
//  Copyright © 2018年 tianNanYiHao. All rights reserved.
//

#import <Foundation/Foundation.h>
#import <UIKit/UIKit.h>
@interface SOCR : NSObject


- (void)loadSOCRwith:(UIViewController*)currentVC;


@end
