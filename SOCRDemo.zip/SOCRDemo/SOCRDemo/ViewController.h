//
//  ViewController.h
//  SOCRDemo
//
//  Created by tianNanYiHao on 2018/7/20.
//  Copyright © 2018年 tianNanYiHao. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface ViewController : UIViewController


@end

